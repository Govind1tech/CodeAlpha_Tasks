public class Stock {
    private final String ticker;
    private final String name;
    private double currentPrice;

    public Stock(String ticker, String name, double currentPrice) {
        this.ticker = ticker.toUpperCase();
        this.name = name;
        this.currentPrice = Math.max(0.01, currentPrice);
    }

    public String getTicker() { return ticker; }
    public String getName() { return name; }
    public double getCurrentPrice() { return currentPrice; }

    public void updatePrice(double newPrice) {
        if (newPrice > 0) {
            this.currentPrice = Math.round(newPrice * 100.0) / 100.0;
        }
    }

    public String toJson() {
        return String.format("{\"ticker\":\"%s\",\"name\":\"%s\",\"price\":%.2f}", ticker, name, currentPrice);
    }
}