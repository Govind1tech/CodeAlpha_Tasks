import java.util.*;

public class TradingPlatform {
    private final String saveFile = "portfolio_data.txt";
    private final Map<String, Stock> market;
    private UserPortfolio portfolio;
    private final Scanner scanner;

    public TradingPlatform() {
        this.market = new HashMap<>();
        this.scanner = new Scanner(System.in);
        initializeMarket();
    }

    private void initializeMarket() {
        Stock[] initialStocks = {
            new Stock("AAPL", "Apple Inc.", 175.50),
            new Stock("GOOGL", "Alphabet Inc.", 150.25),
            new Stock("TSLA", "Tesla Inc.", 180.00),
            new Stock("AMZN", "Amazon.com Inc.", 178.10),
            new Stock("NVDA", "NVIDIA Corp.", 850.00)
        };
        for (Stock s : initialStocks) {
            market.put(s.getTicker(), s);
        }
    }

    public void displayMarket() {
        System.out.println("\n=== CURRENT MARKET DATA ===");
        System.out.printf("%-8s%-20s%-12s\n", "Ticker", "Company Name", "Current Price");
        System.out.println("----------------------------------------");
        for (Stock stock : market.values()) {
            System.out.printf("%-8s%-20s$% -12.2f\n", stock.getTicker(), stock.getName(), stock.getCurrentPrice());
        }
    }

    public void displayPortfolio() {
        if (portfolio == null) return;
        System.out.printf("\n=== PORTFOLIO PERFORMANCE FOR: %s ===\n", portfolio.getUsername().toUpperCase());
        System.out.printf("Available Cash: $%,.2f\n\n", portfolio.getCash());
        System.out.println("--- Current Holdings ---");
        
        if (portfolio.getHoldings().isEmpty()) {
            System.out.println("No stocks owned currently.");
        } else {
            System.out.printf("%-8s%-10s%-15s%-12s\n", "Ticker", "Shares", "Current Price", "Total Value");
            System.out.println("------------------------------------------------");
            for (Map.Entry<String, Integer> entry : portfolio.getHoldings().entrySet()) {
                Stock stock = market.get(entry.getKey());
                double price = (stock != null) ? stock.getCurrentPrice() : 0.0;
                double total = entry.getValue() * price;
                System.out.printf("%-8s%-10d$%-14.2f$%,-12.2f\n", entry.getKey(), entry.getValue(), price, total);
            }
        }
        System.out.println("------------------------------------------------");
        System.out.printf("Total Portfolio Value: $%,.2f\n", portfolio.getTotalValue(market));
    }

    public void displayHistory() {
        if (portfolio == null || portfolio.getHistory().isEmpty()) {
            System.out.println("\n📜 No transaction history found.");
            return;
        }
        System.out.println("\n📜 === TRANSACTION HISTORY ===");
        System.out.printf("%-22s%-8s%-8s%-8s%-12s\n", "Timestamp", "Action", "Ticker", "Shares", "Execution Price");
        System.out.println("----------------------------------------------------------");
        for (Transaction tx : portfolio.getHistory()) {
            System.out.printf("%-22s%-8s%-8s%-8d$%-12.2f\n", tx.getTimestamp(), tx.getAction(), tx.getTicker(), tx.getShares(), tx.getPrice());
        }
    }

    public void setupUser() {
        System.out.println("📈 Welcome to the OOP Java Paper Trading Platform 📈");
        System.out.print("Enter your username: ");
        String username = scanner.nextLine().trim();

        UserFileHandler: {
            UserPortfolio loaded = UserPortfolio.loadFromFile(saveFile);
            if (loaded != null && loaded.getUsername().equalsIgnoreCase(username)) {
                this.portfolio = loaded;
                System.out.println("Welcome back, " + username + "! Data loaded successfully.");
                break UserFileHandler;
            }
            this.portfolio = new UserPortfolio(username, 10000.00);
            System.out.println("Created a fresh demo account for " + username + " with $10,000.00 cash setup.");
        }
    }

    public void run() {
        setupUser();
        while (true) {
            System.out.println("\n[1] View Market Data  [2] View Portfolio  [3] Buy Stock");
            System.out.println("[4] Sell Stock        [5] Trade History    [6] Deposit Cash   [7] Save & Exit");
            System.out.print("Select an option (1-7): ");
            String choice = scanner.nextLine().trim();

            switch (choice) {
                case "1" -> displayMarket();
                case "2" -> displayPortfolio();
                case "3", "4" -> {
                    System.out.print("Enter Stock Ticker: ");
                    String ticker = scanner.nextLine().trim().toUpperCase();
                    if (!market.containsKey(ticker)) {
                        System.out.println("❌ Error: Ticker not found in market asset listings.");
                        continue;
                    }
                    System.out.print("Enter number of shares: ");
                    try {
                        int shares = Integer.parseInt(scanner.nextLine().trim());
                        if (shares <= 0) {
                            System.out.println("❌ Error: Share count must be a positive integer value.");
                            continue;
                        }
                        if (choice.equals("3")) {
                            portfolio.executeBuy(market.get(ticker), shares);
                        } else {
                            portfolio.executeSell(market.get(ticker), shares);
                        }
                    } catch (NumberFormatException e) {
                        System.out.println("❌ Error: Invalid input type; must be an integer.");
                    }
                }
                case "5" -> displayHistory();
                case "6" -> {
                    System.out.print("Enter amount to deposit: $");
                    try {
                        double amount = Double.parseDouble(scanner.nextLine().trim());
                        portfolio.depositCash(amount);
                    } catch (NumberFormatException e) {
                        System.out.println("❌ Error: Invalid amount entered.");
                    }
                }
                case "7" -> {
                    portfolio.saveToFile(saveFile);
                    System.out.println("Double checked state synchronization... 100% saved. Goodbye!");
                    return;
                }
                default -> System.out.println("❌ Invalid option selected. Please try again.");
            }
        }
    }

    public static void main(String[] args) {
        new TradingPlatform().run();
    }
}