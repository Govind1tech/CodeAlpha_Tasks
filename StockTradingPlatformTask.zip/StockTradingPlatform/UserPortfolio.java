import java.io.*;
import java.util.*;

public class UserPortfolio {
    private final String username;
    private double cash;
    private final Map<String, Integer> holdings;
    private final List<Transaction> history;

    public UserPortfolio(String username, double initialCash) {
        this.username = username;
        this.cash = initialCash;
        this.holdings = new HashMap<>();
        this.history = new ArrayList<>();
    }

    public String getUsername() { return username; }
    public double getCash() { return cash; }
    public Map<String, Integer> getHoldings() { return holdings; }
    public List<Transaction> getHistory() { return history; }

    public boolean executeBuy(Stock stock, int shares) {
        double totalCost = stock.getCurrentPrice() * shares;
        if (this.cash < totalCost) {
            System.out.printf("❌ Error: Insufficient funds. Required: $%.2f, Available: $%.2f\n", totalCost, this.cash);
            return false;
        }

        this.cash -= totalCost;
        this.holdings.put(stock.getTicker(), holdings.getOrDefault(stock.getTicker(), 0) + shares);
        this.history.add(new Transaction("BUY", stock.getTicker(), shares, stock.getCurrentPrice()));
        
        System.out.printf("✅ Successfully bought %d shares of %s at $%.2f each.\n", shares, stock.getTicker(), stock.getCurrentPrice());
        return true;
    }

    public boolean executeSell(Stock stock, int shares) {
        int ownedShares = holdings.getOrDefault(stock.getTicker(), 0);
        if (ownedShares < shares) {
            System.out.printf("❌ Error: Insufficient shares. Owned: %d, Attempted to sell: %d\n", ownedShares, shares);
            return false;
        }

        double totalGain = stock.getCurrentPrice() * shares;
        this.cash += totalGain;
        this.holdings.put(stock.getTicker(), ownedShares - shares);

        if (this.holdings.get(stock.getTicker()) == 0) {
            this.holdings.remove(stock.getTicker());
        }

        this.history.add(new Transaction("SELL", stock.getTicker(), shares, stock.getCurrentPrice()));
        System.out.printf("✅ Successfully sold %d shares of %s at $%.2f each.\n", shares, stock.getTicker(), stock.getCurrentPrice());
        return true;
    }

    public double getTotalValue(Map<String, Stock> marketStocks) {
        double holdingsValue = 0;
        for (Map.Entry<String, Integer> entry : holdings.entrySet()) {
            Stock stock = marketStocks.get(entry.getKey());
            if (stock != null) {
                holdingsValue += entry.getValue() * stock.getCurrentPrice();
            }
        }
        return Math.round((this.cash + holdingsValue) * 100.0) / 100.0;
    }

    // Persist portfolio using structured flat-file configuration
    public void saveToFile(String filename) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filename))) {
            writer.write(username + "\n");
            writer.write(cash + "\n");
            
            // Save Holdings
            writer.write(holdings.size() + "\n");
            for (Map.Entry<String, Integer> entry : holdings.entrySet()) {
                writer.write(entry.getKey() + "," + entry.getValue() + "\n");
            }
            
            // Save History
            writer.write(history.size() + "\n");
            for (Transaction tx : history) {
                writer.write(String.format("%s,%s,%d,%.2f,%s\n", 
                    tx.getAction(), tx.getTicker(), tx.getShares(), tx.getPrice(), tx.getTimestamp()));
            }
        } catch (IOException e) {
            System.out.println("❌ Failed to save data: " + e.getMessage());
        }
    }

    public static UserPortfolio loadFromFile(String filename) {
        File file = new File(filename);
        if (!file.exists()) return null;

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String username = reader.readLine();
            double cash = Double.parseDouble(reader.readLine());
            UserPortfolio portfolio = new UserPortfolio(username, cash);

            int holdingsSize = Integer.parseInt(reader.readLine());
            for (int i = 0; i < holdingsSize; i++) {
                String[] parts = reader.readLine().split(",");
                portfolio.holdings.put(parts[0], Integer.valueOf(parts[1]));
            }

            int historySize = Integer.parseInt(reader.readLine());
            for (int i = 0; i < historySize; i++) {
                String[] parts = reader.readLine().split(",");
                portfolio.history.add(new Transaction(parts[0], parts[1], Integer.parseInt(parts[2]), Double.parseDouble(parts[3]), parts[4]));
            }
            return portfolio;
        } catch (Exception e) {
            System.out.println("⚠️ Data parsing failure. Initializing fresh account context.");
            return null;
        }
    }

public void depositCash(double amount) {
    if (amount > 0) {
        this.cash += amount;
        // Optional: Log it in your transaction history
        this.history.add(new Transaction("DEP", "CASH", 0, amount));
        System.out.printf("💵 Successfully deposited $%.2f. New Balance: $%.2f\n", amount, this.cash);
    } else {
        System.out.println("❌ Error: Deposit amount must be positive.");
    }
}
}