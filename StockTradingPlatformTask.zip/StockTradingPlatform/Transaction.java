import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Transaction {
    private final String action; // "BUY" or "SELL"
    private final String ticker;
    private final int shares;
    private final double price;
    private final String timestamp;

    public Transaction(String action, String ticker, int shares, double price) {
        this.action = action.toUpperCase();
        this.ticker = ticker.toUpperCase();
        this.shares = shares;
        this.price = price;
        this.timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
    }

    // Constructor for loading historical data
    public Transaction(String action, String ticker, int shares, double price, String timestamp) {
        this.action = action;
        this.ticker = ticker;
        this.shares = shares;
        this.price = price;
        this.timestamp = timestamp;
    }

    public String getAction() { return action; }
    public String getTicker() { return ticker; }
    public int getShares() { return shares; }
    public double getPrice() { return price; }
    public String getTimestamp() { return timestamp; }

    public String toJson() {
        return String.format("{\"action\":\"%s\",\"ticker\":\"%s\",\"shares\":%d,\"price\":%.2f,\"timestamp\":\"%s\"}",
                action, ticker, shares, price, timestamp);
    }
}